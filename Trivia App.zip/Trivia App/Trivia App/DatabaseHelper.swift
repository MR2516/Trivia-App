//
//  DatabaseHelper.swift
//  Trivia App
//
//  Created by My Universe on 04/01/22.
//

import Foundation
import CoreData
import UIKit

class DatabaseHelper {
    
    static var shareInstance = DatabaseHelper()
    
    let context  = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    func save(object:[String:String]){
        let trivia = NSEntityDescription.insertNewObject(forEntityName: "Trivia", into: context!) as! Trivia
        trivia.name = object["name"]
        trivia.cricketer = object["cricketer"]
        trivia.colors = object["colors"]
        trivia.date = object["date"]
        
        do{
            try context?.save()
        }catch{
            print("Data is not save")
        }
    }
    
    func getTriviaData() -> [Trivia] {
        var trivia = [Trivia]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Trivia")
        do{
            trivia = try context?.fetch(fetchRequest) as! [Trivia]
         }catch{
            print("Can not get data")
         }
        return trivia
    }
}
