//
//  HistoryTVC.swift
//  Trivia App
//
//  Created by My Universe on 05/01/22.
//

import UIKit

class HistoryTVC: UITableViewCell {

    @IBOutlet weak var lblGameStartDate: UILabel!
    @IBOutlet weak var lblHistoryName: UILabel!
    @IBOutlet weak var lblHistoryCricketer: UILabel!
    @IBOutlet weak var lblHistoryColors: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
