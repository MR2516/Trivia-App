//
//  HistoryVC.swift
//  Trivia App
//
//  Created by My Universe on 04/01/22.
//

import UIKit

class HistoryVC: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tblHistory: UITableView!
    
    var trivia = [Trivia]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        trivia = DatabaseHelper.shareInstance.getTriviaData()
    }
    
    @IBAction func ActionBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return trivia.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HistoryTVC") as! HistoryTVC
        let tag = indexPath.row + 1
        cell.lblGameStartDate.text! = "Game" + String(tag) + ": " + (trivia[indexPath.row].date!)
        cell.lblHistoryName.text! = "Name: " + (trivia[indexPath.row].name!)
        cell.lblHistoryCricketer.text! = "Answers: " + (trivia[indexPath.row].cricketer!)
        cell.lblHistoryColors.text! = "Answers: " + (trivia[indexPath.row].colors?.replacingOccurrences(of: " ", with: ", "))!
        return cell
    }
}
