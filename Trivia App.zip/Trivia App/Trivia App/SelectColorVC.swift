//
//  SelectColorVC.swift
//  Trivia App
//
//  Created by My Universe on 04/01/22.
//

import UIKit

class SelectColorVC: UIViewController {

    @IBOutlet weak var lblOption1: UILabel!
    @IBOutlet weak var btnOption1: UIButton!
    
    @IBOutlet weak var lblOption2: UILabel!
    @IBOutlet weak var btnOption2: UIButton!
    
    @IBOutlet weak var lblOption3: UILabel!
    @IBOutlet weak var btnOption3: UIButton!
    
    @IBOutlet weak var lblOption4: UILabel!
    @IBOutlet weak var btnOption4: UIButton!
    
    @IBOutlet weak var lblOption5: UILabel!
    @IBOutlet weak var btnOption5: UIButton!
    
    @IBOutlet weak var lblOption6: UILabel!
    @IBOutlet weak var btnOption6: UIButton!
    
    @IBOutlet weak var lblOption7: UILabel!
    @IBOutlet weak var btnOption7: UIButton!
    
    @IBOutlet weak var lblOption8: UILabel!
    @IBOutlet weak var btnOption8: UIButton!
    
    var t1 = 0
    var t2 = 0
    var t3 = 0
    var t4 = 0
    var t5 = 0
    var t6 = 0
    var t7 = 0
    var t8 = 0
    
    var aryColors: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func SelectColor(_ sender: UIButton) {
       
        let tag = sender.tag
        switch tag {
        case 1:
            if t1 == 0{
                btnOption1.isSelected = true
                aryColors.append(lblOption1.text!)
                t1 = 1
            } else {
                t1 = 0
                btnOption1.isSelected = false
                let colorToRemove = lblOption1.text!
                for object in aryColors {
                    if object == colorToRemove {
                        aryColors.remove(at: aryColors.firstIndex(of: colorToRemove)!)
                    }
                }
            }
        case 2:
            if t2 == 0{
                btnOption2.isSelected = true
                aryColors.append(lblOption2.text!)
                t2 = 1
            } else {
                t2 = 0
                btnOption2.isSelected = false
                let colorToRemove = lblOption2.text!
                for object in aryColors {
                    if object == colorToRemove {
                        aryColors.remove(at: aryColors.firstIndex(of: colorToRemove)!)
                    }
                }
            }

        case 3:
            if t3 == 0{
                btnOption3.isSelected = true
                aryColors.append(lblOption3.text!)
                t3 = 1
            } else {
                t3 = 0
                btnOption3.isSelected = false
                let colorToRemove = lblOption3.text!
                for object in aryColors {
                    if object == colorToRemove {
                        aryColors.remove(at: aryColors.firstIndex(of: colorToRemove)!)
                    }
                }
            }

        case 4:
            if t4 == 0{
                btnOption4.isSelected = true
                aryColors.append(lblOption4.text!)
                t4 = 1
            } else {
                t4 = 0
                btnOption4.isSelected = false
                let colorToRemove = lblOption4.text!
                for object in aryColors {
                    if object == colorToRemove {
                        aryColors.remove(at: aryColors.firstIndex(of: colorToRemove)!)
                    }
                }
            }

        case 5:
            if t5 == 0{
                btnOption5.isSelected = true
                aryColors.append(lblOption5.text!)
                t5 = 1
            } else {
                t5 = 0
                btnOption5.isSelected = false
                let colorToRemove = lblOption5.text!
                for object in aryColors {
                    if object == colorToRemove {
                        aryColors.remove(at: aryColors.firstIndex(of: colorToRemove)!)
                    }
                }
            }

        case 6:
            if t6 == 0{
                btnOption6.isSelected = true
                aryColors.append(lblOption6.text!)
                t6 = 1
            } else {
                t6 = 0
                btnOption6.isSelected = false
                let colorToRemove = lblOption6.text!
                for object in aryColors {
                    if object == colorToRemove {
                        aryColors.remove(at: aryColors.firstIndex(of: colorToRemove)!)
                    }
                }
            }

        case 7:
            if t7 == 0{
                btnOption7.isSelected = true
                aryColors.append(lblOption7.text!)
                t7 = 1
            } else {
                t7 = 0
                btnOption7.isSelected = false
                let colorToRemove = lblOption7.text!
                for object in aryColors {
                    if object == colorToRemove {
                        aryColors.remove(at: aryColors.firstIndex(of: colorToRemove)!)
                    }
                }
            }

        case 8:
            if t8 == 0{
                btnOption8.isSelected = true
                aryColors.append(lblOption8.text!)
                t8 = 1
            } else {
                t8 = 0
                btnOption8.isSelected = false
                let colorToRemove = lblOption8.text!
                for object in aryColors {
                    if object == colorToRemove {
                        aryColors.remove(at: aryColors.firstIndex(of: colorToRemove)!)
                    }
                }
            }
        default:
            break
        }
    }
    
    @IBAction func ActionNext(_ sender: Any) {
        if aryColors.isEmpty {
            let alert = UIAlertController(title: "alert..!", message: "Please Select your flag Colors", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        } else {
            let vc = storyboard?.instantiateViewController(withIdentifier: "SummaryVC") as! SummaryVC
            arrayColors = aryColors
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
