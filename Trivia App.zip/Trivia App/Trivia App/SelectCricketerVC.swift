//
//  SelectCricketerVC.swift
//  Trivia App
//
//  Created by My Universe on 04/01/22.
//

import UIKit

class SelectCricketerVC: UIViewController {
    
    @IBOutlet weak var lblOption1: UILabel!
    @IBOutlet weak var btnOption1: UIButton!
    
    @IBOutlet weak var lblOption2: UILabel!
    @IBOutlet weak var btnOption2: UIButton!
    
    @IBOutlet weak var lblOption3: UILabel!
    @IBOutlet weak var btnOption3: UIButton!
    
    @IBOutlet weak var lblOption4: UILabel!
    @IBOutlet weak var btnOption4: UIButton!
    
    var cricketerName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func SelectOption(_ sender: UIButton) {
        let tag = sender.tag
        if tag == 1 {
            btnOption1.isSelected = true
            btnOption2.isSelected = false
            btnOption3.isSelected = false
            btnOption4.isSelected = false
            cricketerName = lblOption1.text!
            
        } else if tag == 2 {
            btnOption1.isSelected = false
            btnOption2.isSelected = true
            btnOption3.isSelected = false
            btnOption4.isSelected = false
            cricketerName = lblOption2.text!
            
        } else if tag == 3 {
            btnOption1.isSelected = false
            btnOption2.isSelected = false
            btnOption3.isSelected = true
            btnOption4.isSelected = false
            cricketerName = lblOption3.text!
            
        } else {
            btnOption1.isSelected = false
            btnOption2.isSelected = false
            btnOption3.isSelected = false
            btnOption4.isSelected = true
            cricketerName = lblOption4.text!
        }
    }
    
    @IBAction func ActionNext(_ sender: Any) {
        if cricketerName != "" {
            let vc = storyboard?.instantiateViewController(withIdentifier: "SelectColorVC") as! SelectColorVC
            cricketer = cricketerName
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            let alert = UIAlertController(title: "alert..!", message: "Please Select your best Cricketer", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
    }
}
