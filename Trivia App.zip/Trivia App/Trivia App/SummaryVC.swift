//
//  SummaryVC.swift
//  Trivia App
//
//  Created by My Universe on 04/01/22.
//

import UIKit

class SummaryVC: UIViewController {

    @IBOutlet weak var lblShowName: UILabel!
    @IBOutlet weak var lblShowCricketer: UILabel!
    @IBOutlet weak var lblShowColors: UILabel!
    
    var date_time = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblShowName.text! = "Hello " + "'" + userName + "'"
        lblShowCricketer.text! = "Answers: " + cricketer
        lblShowColors.text! = "Answers: " + arrayColors.joined(separator: ",")
        
        let date = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM, HH:mm a"
        date_time = dateFormatter.string(from: date)
        print(date_time)
    }

    @IBAction func ActionFinish(_ sender: Any) {
        let stringDate = date_time.replacingOccurrences(of: " ", with: "%20")
        let dict = ["name": userName, "cricketer": cricketer, "colors": arrayColors.joined(separator: " "), "date": date_time] as [String : String]
        DatabaseHelper.shareInstance.save(object: dict)
        self.navigationController?.popToRootViewController(animated: true)
    }
}
