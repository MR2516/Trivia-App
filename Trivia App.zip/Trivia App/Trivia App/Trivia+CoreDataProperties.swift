//
//  Trivia+CoreDataProperties.swift
//  Trivia App
//
//  Created by My Universe on 05/01/22.
//
//

import Foundation
import CoreData


extension Trivia {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Trivia> {
        return NSFetchRequest<Trivia>(entityName: "Trivia")
    }

    @NSManaged public var colors: String?
    @NSManaged public var cricketer: String?
    @NSManaged public var datetime: String?
    @NSManaged public var name: String?

}

extension Trivia : Identifiable {

}
