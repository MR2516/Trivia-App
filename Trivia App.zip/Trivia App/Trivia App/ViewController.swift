//
//  ViewController.swift
//  Trivia App
//
//  Created by My Universe on 04/01/22.
//

import UIKit

var userName = ""
var cricketer = ""
var arrayColors: [String] = []

class ViewController: UIViewController {
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var btnHistory: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        let no = DatabaseHelper.shareInstance.getTriviaData().count
        if no != 0 {
            btnHistory.isHidden = false
        } else {
            btnHistory.isHidden = true
        }
    }

    @IBAction func ActionHistory(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "HistoryVC") as! HistoryVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func ActionNext(_ sender: Any) {
        if txtName.text! != "" {
            let vc = storyboard?.instantiateViewController(withIdentifier: "SelectCricketerVC") as! SelectCricketerVC
            userName = txtName.text!
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            let alert = UIAlertController(title: "alert..!", message: "Please enter Name", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
    }
}

