//
//  Trivia+CoreDataClass.swift
//  Trivia App
//
//  Created by My Universe on 05/01/22.
//
//

import Foundation
import CoreData

@objc(Trivia)
public class Trivia: NSManagedObject {

}
